# Sharbat Hotel Website

## Структура файлов

```
sharbat/
├── server.js          ← Node.js сервер (без зависимостей!)
├── public/
│   ├── index.html     ← Главный сайт
│   ├── admin.html     ← Админ-панель
│   └── uploads/       ← Фото сохраняются сюда (создаётся автоматически)
└── data/
    └── items.json     ← База данных (создаётся автоматически)
```

## Запуск

```bash
node server.js
```

Сайт: http://localhost:3000
Админ: http://localhost:3000/admin

## Возможности

### Главный сайт (/)
- Полностью мобильный дизайн
- Переключатель RU / EN
- Меню с фильтрами по категориям
- Галерея террасы
- Lightbox для просмотра фото

### Админ-панель (/admin)
- Добавление блюд: фото + название RU/EN + описание RU/EN + цена + категория
- Добавление фото террасы с подписями
- Просмотр всех добавленных элементов
- Удаление с подтверждением
- Все фото сохраняются на сервере в /public/uploads/
- Данные хранятся в /data/items.json

## API эндпоинты

- GET  /api/items?type=menu|terrace
- POST /api/items?type=menu|terrace  (multipart/form-data)
- DELETE /api/items/:id?type=menu|terrace

## Требования

Только Node.js (v14+). Никаких npm-зависимостей!
